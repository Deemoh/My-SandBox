sap.ui.define([
	"root/ui5python/test/unit/controller/BView.controller"
], function () {
	"use strict";
});
