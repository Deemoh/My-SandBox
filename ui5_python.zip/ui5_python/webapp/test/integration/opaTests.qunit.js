/* global QUnit */

sap.ui.require(["root/ui5python/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
